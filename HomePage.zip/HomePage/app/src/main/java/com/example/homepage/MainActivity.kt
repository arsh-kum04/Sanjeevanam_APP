package com.example.homepage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.viewpager.widget.ViewPager

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var imgs : List<Int> = listOf<Int>(R.drawable.akums_blood_donation_banner__1_,R.drawable._f351f8b07baf6049984c2d311d770e1,R.drawable.akums_blood_donation_banner__1_,R.drawable._f351f8b07baf6049984c2d311d770e1)
        var adapter = Adapter(imgs, this)
        var pager = findViewById<ViewPager>(R.id.pager)
        pager.adapter = adapter
    }
}